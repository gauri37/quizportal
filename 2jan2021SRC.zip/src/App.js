
import './App.css';
import MainPage from './component/MainPage';
function App() {
  return (

    <div className="App">
     
     <MainPage/>
    </div>

  );
}

export default App;
