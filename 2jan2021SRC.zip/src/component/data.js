const data = [
    {
        Qno: 1,
        Question: "Find the sum of 111 + 222 + 333",
        A: 700,
        B: 666,
        C: 10,
        D:100,
        correctAns : 666
    },
    {
        Qno: 2,
        Question: "Subtract 457 from 832",
        A: 375,
        B: 666,
        C: 10,
        D:100,
        correctAns : 375

    },
    {
        Qno: 3,
        Question: " 90 รท 10",
        A: 9,
        B: 10,
        C: 100,
        D:1,
        correctAns : 9
    },

    {
        Qno: 4,
        Question: "Simplify: 26 + 32 - 12",
        A: 0,
        B: 32,
        C: 56,
        D: 46,
        correctAns : 46
    },

    {
        Qno: 5,
        Question: "Find the product of 72 ร— 3",
        A: 216,
        B: 7230,
        C: 106,
        D: 372,
        correctAns : 216
    },
]

export default data;