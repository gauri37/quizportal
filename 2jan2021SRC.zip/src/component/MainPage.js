import react from 'react';
import './MainPage.css';
export default class MainPage extends react.Component
{
    openNav(){
        document.getElementById("mySidebar").style.width = "250px";
        document.getElementById("main").style.marginLeft = "250px";
      }
    render()
    {
        return (
          <div class="constainer-fluid">
                  <div class="topnav">
                  <a href="#about" class="dropdown" >☰ Quiz Menu</a>
                  <div class="topnav-right">
                  <a href="#search">Search</a>
                  <a href="#about"><i class="fa fa-fw fa-user"></i>Username</a>
              </div>
            </div>

            <div class="sidenav">
                    <a href="#about" class="h1">☰ Quiz Menu</a>
                    <a href="#services">JS Data Type</a>
                    <a href="#clients">Hoisting</a>
                    <a href="#contact">Function</a>
                    <a href="#services">IIFE</a>
                    <a href="#clients">Closure</a>
                    <a href="#contact">Promises</a>
                    <a href="#services">JS Object</a>
                    <a href="#services">let,const,var</a>
                    <a href="#clients">asyc and await</a>
                   
            </div>
            <div class="row justify-content-center">
              <div class="boxforquiz ">
              <div class="section-title">Progress Status</div>
              <div class="sub-title">Overall Quizz</div>
              <div class="sub-title">0/9</div>
              <div class="percentage">0%</div>
            </div>
            </div>
</div>
           

        )
    }
}





