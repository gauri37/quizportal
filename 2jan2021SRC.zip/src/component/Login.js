import react from 'react';
import './login.css';
export default class Login extends react.Component
{
    render()
    {
        return (
            <div className="logindiv">
                <div className="innerdiv">
                <form class="form-start">
                <span class="title">
                Login	
                </span>
                <div class="user-div">
                    <input type="text" class="inputcss-user" name="userName" placeholder="Enter Username"/>
                </div>
                
                <div class="user-div">
                        <input type="password" class="inputcss-pass" name="password" placeholder="Enter Password"/>
                
</div>
                <button className="btnlogin">Login</button>
                <div class="text-right">
                    <a href="">Forgot Password?</a>
                </div> 
                <a href="./src/component/signup" class="txt2">Sign Up</a>
                
                </form>
                </div>
            </div>
            
        )
    }
}





