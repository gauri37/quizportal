import react from 'react';
import './StartPage.css';

import Login from './Login';

export default class StartPage extends react.Component
{
    constructor()
    {
        super();
        this.state = {
            isBtnClicked : false
        }
        this.btnClicked = this.btnClicked.bind(this);
    }

    btnClicked(){
        this.setState({
            isBtnClicked : true
        })
    }

    render()
    {
        return (
            
            this.state.isBtnClicked ? <Login /> : (
            <div className="mainPage">
                <button className="gotologin" onClick={this.btnClicked}>
                <i class="fa fa-user-circle-o"></i>
               Get Started Now!</button>
                                
            </div>)
            
        )
    }
}
