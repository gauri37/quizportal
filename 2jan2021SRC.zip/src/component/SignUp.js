import react from 'react';
import './SignUp.css';
export default class signup extends react.Component
{
    render()
    {
        return (
            
                <div className="signupdiv">
                <div className="innerdiv">
                <form class="form-start">
                <span class="title">
                Create Account	
                </span>
                <div class="user-div">
                    <input type="text" class="inputcss-user" name="userName" placeholder="Enter Username"/>
                </div>

                <div class="user-div">
                    <input type="text" class="inputcss-user" name="Email" placeholder="Enter Email" required pattern="[^@]+@[^@]+.[a-zA-Z]{2,6}"/>
                </div>
                
                <div class="user-div">
                    <input type="password" class="inputcss-pass" name="password" placeholder="Enter Password"/>
                </div>

                <div class="user-div">
                    <input type="password" class="inputcss-pass" name="Confirm password" placeholder="Confirm Password"/>
                </div>

                <button className="btnsignup">Sign Up</button> 
               
                
                </form>
                </div>
            </div>
            
        )
    }
}